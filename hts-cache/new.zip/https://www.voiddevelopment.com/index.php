<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang=”tr”>
<head>
<title>Void Development Team | Resmi WebSayfası</title>
    <meta name="author" content="Mehmet Taşkın">
    <meta name="language" content="Turkish">

    <meta charset="UTF-8">
<link rel="icon" 
      type="image/png" 
      href="/images/vd.ico" />
      
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
    <meta name="publisher" content="Mehmet Taşkın">
    <meta name="twitter:card" content="summary"></meta>

<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Void Development Team™  Resmi Web Sitesidir..." />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<!--animated-css-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script>
<!--/animated-css-->
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,300italic,400italic,600italic,700italic' rel='stylesheet' type='text/css'>
<!---- start-smoth-scrolling---->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},900);
				});
			});
		</script>
<!---- start-smoth-scrolling---->

    <link rel="canonical" href="https://www.voiddevelopment.com">
</head>
<body>
<!---->
<div class="banner">
	 <div class="container">
		 <div class="header">
			 <div class="logo wow fadeInLeft" data-wow-delay="0.5s">
			 <a href="index.php"><img src="images/logo.png" title="Void Development Team" alt="Void Development Team"/></a>
			 </div>
			 <div class="top-menu">
			 <span class="menu"></span>
				 <ul>
				 <li class="active"><a title="Ana Sayfa" href="index.php">Ana Sayfa</a></li>
				 <li><a class="scroll" title="Hakkımızda" href="#about">Hakkımızda</a></li>
				 <li><a class="scroll" title="Farkımız" href="#features">Farkımız</a></li>
				 <li><a class="scroll" title="Müşteri Yorumları" href="#testimonials">Müşteri Yorumları</a></li>
				 <li><a class="scroll" title="İletişim" href="#contact">İletişim</a></li>
				 </ul>
			 </div>
			  <!-- script-for-menu -->
		 <script>
				$("span.menu").click(function(){
					$(".top-menu ul").slideToggle("slow" , function(){
					});
				});
		 </script>
		 <!-- script-for-menu -->	  	

			 <div class="clearfix"></div>
		 </div>
		 
		 
		 		 
		 
		 
		 <div class="banner-info">
			 <div class="col-md-6 banner-text wow fadeInRight" data-wow-delay="0.5s">
				 <h3>Void Development Team™</h3>
				 <h1>Profesyonel Bir Web Sitesine Sahip Olmanın Zamanı Geldi...</h1>
				 <p>Void Development Team™ Olarak Hayallerinizdeki Web Sitesini Tasarlamak İçin Sizlerleyiz!</p>
				 <a class="download" href="#">Örnek Sitelerimiz</a>
			<!--	 <a class="view hvr-bounce-to-left" class="scroll" href="#feautures">VIEW FEATURES</a>-->
			 </div>
			 <div class="col-md-6 banner-pic wow fadeInLeft" data-wow-delay="0.5s">
				 <img title="Void Development Team" src="images/phn.png" alt=""/>
			 </div>
			 <div class="clearfix"></div>
		 </div>
	 </div>
</div>






<!---->
<div id="features" class="features">
	 <div class="container">
		 <div class="features-head">
			 <h4>FARKLARIMIZ!!</h4>
			 <h3>Bizi Diğer Web Sitesi Yapımcılarından Ayıran Bazı Farklarımız</h3>			 
		 </div>
		 <div class="features-section">
			 <div class="col-md-3 feature-grid">
				 <img class="wow bounceIn" data-wow-delay="0.4s" title="Mükemmel Görünüm" src="images/icon1.png" alt="Mükemmel Görünüm"/>
				 <h3>Uyumlu</h3>
				 <p>Her Cihazdan Mükemmel Görünüm Sağlıyoruz...</p>
			 </div>
			 <div class="col-md-3 feature-grid">
				 <img class="wow bounceIn" data-wow-delay="0.4s" title="Kolay Yönetim" src="images/icon2.png" alt="Kolay Yönetim"/>
				 <h3>Ayarlanabilir</h3>
				 <p>İçerikleri Size Oluşturacağımız Panelden Yönetebilir Değiştirebilirsiniz...</p>
			 </div>
			 <div class="col-md-3 feature-grid">
				 <img class="wow bounceIn" data-wow-delay="0.4s" title="Müşteri Memnuniyeti" src="images/icon3.png" alt="Müşteri Memnuniyeti"/>
				 <h3>Memnun Müşteriler</h3>
				 <p>Müşterilerimiz Onlar İçin Yaptığımız Sitelerden Memnun Kalıyor...</p>
			 </div>
			 <div class="col-md-3 feature-grid">
				 <img class="wow bounceIn" data-wow-delay="0.4s" src="images/icon4.png" alt="Şık Tasarım" title="Şık Tasarım"/>
				 <h3>Göz Alıcı Tasarım</h3>
				 <p>Sitenizin Mükemmel Tasarımıyla Kullanıcılarınızın Vazgeçilmez Web Sitesi Olacaksınız...</p>
			 </div>
			 <div class="clearfix"></div>
		 </div>
	 </div>
</div>






<div id="about" class="about">
	 <div class="container">
		 <div class="about-top">
			 <div class="col-md-6 about-device wow fadeInLeft" data-wow-delay="0.5s">
				 <img src="images/vd.png" alt="Void Development Team" title="Void Development Team"/>
			 </div>
			 <div class="col-md-6 about-device-info wow fadeInRight" data-wow-delay="0.5s">
				 <div class="device-text">
					 <h4>Void Development Team™ Nedir?</h4>
					 <h3>Biz Kimiz?</h3>					 
					 <p>Void Development Team™, Sizlerin Web Sitelerini Tasarlamak vs. Gibi Hizmetler İçin 2020 Yılında Harekete Geçmiş Bir Kodlama Topluluğudur...</p>
				 </div>
				 <div class="about-list">
					 <ul>
						 <li><a href="#"><span class="abt1"></span>Güzel Tasarım</a></li>
						 <li><a href="#"><span class="abt2"></span>Mükemmel Uyum</a></li>
						 <li><a href="#"><span class="abt3"></span>Kolay Yönetim</a></li>
						 <li><a href="#"><span class="abt4"></span>Ve Çok Daha Fazlası...</a></li>
					 </ul>
				 </div>
			 </div>
			 <div class="clearfix"></div>
		 </div>		
	 </div>
</div>
<i class="fas fa-user-friends"></i>
<!--
<div class="about-bottom">
	 <div class="container">
		 <div class="col-md-6 about-customize wow fadeInRight" data-wow-delay="0.5s">
			 <div class="device-text-bottom">
					<h4>DIP INTO THE DETAILS</h4>
					<h3>Super easy to customize</h3>						
					<p>Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. 
					Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non  mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
			 </div>				 
		 </div>
		 <div class="col-md-6 about-device-bottom wow fadeInLeft" data-wow-delay="0.5s">
				<img src="images/phn3.jpg" alt=""/>
		 </div>
		 <div class="clearfix"></div>
	 </div>
</div>-->








  <script src="js/responsiveslides.min.js"></script>
  <script>
    // You can also use "$(window).load(function() {"
    $(function () {
      $("#slider2").responsiveSlides({
        auto: true,
        pager: true,
        speed: 300,
        namespace: "callbacks",
      });
    });
  </script>
<!---->
<div id="testimonials" class="pricing">
	 <div class="container">
		 <div class="pricing-text">
			<h4>Mutlu Müşterilerimiz</h4>
			<h3>Memnun Müşterilerimiz...</h3>				
		 </div>

         
		 <!-- start slider -->	
		 <div class="pricing-grids">
			 <div class="slider">
				 <ul class="rslides" id="slider2">
					 <li>						 
					     <div class="col-md-6 pricing-plans">
							  <p>Once upon a time all the Rivers combined to protest against the action of the Sea in making their waters salt.
							 “When we come to you,” said they to the Sea.</p>
							  <div class="pic1">
								 <img src="images/pr1.png" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>
						 <div class="col-md-6 pricing-plans">
							  <p>A shoe is not only a design, but it's a part of your body language, the way you walk. The way you're going to move is quite dictated by your shoes.</p>
							  <div class="pic1">
								 <img src="images/pr2.png" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>						
					      <div class="clearfix"></div>						  
					  </li>	
					  <li>						    
						 <div class="col-md-6 pricing-plans">
							  <p>A shoe is not only a design, but it's a part of your body language, the way you walk. The way you're going to move is quite dictated by your shoes.</p>
							  <div class="pic1">
								 <img src="images/pr2.png" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>	
						  <div class="col-md-6 pricing-plans">
							  <p>Once upon a time all the Rivers combined to protest against the action of the Sea in making their waters salt.
							 “When we come to you,” said they to the Sea.</p>
							  <div class="pic1">
								 <img src="images/m2.jpg" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>
					      <div class="clearfix"></div>						  
					  </li>
					  <li>						 
					     <div class="col-md-6 pricing-plans">
							  <p>Once upon a time all the Rivers combined to protest against the action of the Sea in making their waters salt.
							 “When we come to you,” said they to the Sea.</p>
							  <div class="pic1">
								 <img src="images/m1.jpg" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>
						 <div class="col-md-6 pricing-plans">
							  <p>A shoe is not only a design, but it's a part of your body language, the way you walk. The way you're going to move is quite dictated by your shoes.</p>
							  <div class="pic1">
								 <img src="images/pr1.png" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>						
					      <div class="clearfix"></div>						  
					  </li>	
					  <li>						    
						 <div class="col-md-6 pricing-plans">
							  <p>A shoe is not only a design, but it's a part of your body language, the way you walk. The way you're going to move is quite dictated by your shoes.</p>
							  <div class="pic1">
								 <img src="images/pr2.png" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>	
						  <div class="col-md-6 pricing-plans">
							  <p>Once upon a time all the Rivers combined to protest against the action of the Sea in making their waters salt.
							 “When we come to you,” said they to the Sea.</p>
							  <div class="pic1">
								 <img src="images/m2.jpg" alt=""/>
							  </div>
							  <div class="pic-info">
									<h5>John Doe</h5>
									<a href="#">CEO, THE RIVERS COMPANY</a>
							  </div>
							  <div class="clearfix"></div>
						 </div>
					      <div class="clearfix"></div>						  
					  </li>
				  </ul>
			   </div>
			   <!-- end slider -->
		  </div>  	
	 </div>
</div>
<!---->
<div class="theme">
	 <div class="container">
		 <h3 class="wow bounceIn" data-wow-delay="0.4s"><span>Sizce De İşinizi İnternet Üzerinden Yönetmenin Zamanı Gelmedi Mi?</span>Örnek Temalarımızdan Satın Alın ya da Bizimle İletişime Geçin!!</h3><br>
		  <a class="view hvr-bounce-to-left wow bounceIn" data-wow-delay="0.4s" href="#">Örnek Temalarımız</a>
		 <a class="download wow bounceIn" class="scroll"  data-wow-delay="0.4s" title="İletişime Geç" href="index.php#contact">İletişime Geç!</a>
	 </div>
</div>



<!--
<div id="pricing" class="pricing-bottom">
	  <div class="container">
		 <div class="pricing-text-bottom">
			<h4>QUALITY HAS ITS PRICE</h4>
			<h3>Pricings & Plans</h3>			
		 </div>
		  <div class="price-section-grids">
			 <div class="price-value text-center wow fadeInUp" data-wow-delay="0.4s">				  
				  <div class="price-head">
						<h5>Free</h5>
				 </div>
				  <div class="cost">
						<h3><span>$</span>0</h3>
						<p>\ per month</p>
				  </div>
				 <div class="cost-info">
					<p>Fusce fermentum placerat magna ac pharetra. Aliquam euismod elit non ipsum <span>lacinia</span> consectetur.</p>
					<a href="#">ORDER NOW</a>	
				 </div>				 			 
			 </div>
			 <div class="price-value text-center wow fadeInDown" data-wow-delay="0.4s">				  
				 <div class="price-head">
				    <h5>Personal</h5>
				 </div>
				 <div class="cost">
					<h3><span>$</span>25</h3>
					<p>\ per month</p>
				 </div>
				 <div class="cost-info">
					<p>Fusce fermentum placerat magna ac pharetra. Aliquam euismod elit non ipsum <span>lacinia</span> consectetur.</p>
					<a href="#">ORDER NOW</a>	
				 </div>	
		     </div>
			 <div class="price-value text-center wow fadeInUp" data-wow-delay="0.4s">	
					<div class="price-head">
						 <h5>Business</h5>
					</div>
					<div class="cost">
						 <h3><span>$</span>50</h3>
						 <p>\ per month</p>
					</div>
					<div class="cost-info">
					<p>Fusce fermentum placerat magna ac pharetra. Aliquam euismod elit non ipsum <span>lacinia</span> consectetur.</p>
					<a href="#">ORDER NOW</a>	
				    </div>					 
			 </div>
			 <div class="price-value text-center wow fadeInDown" data-wow-delay="0.4s">				  
				 <div class="price-head">
						 <h5>ultimate</h5>
				  </div>
				 <div class="cost">
					 <h3><span>$</span>99</h3>
					 <p>\ per month</p>
				 </div>
				 <div class="cost-info">
					<p>Fusce fermentum placerat magna ac pharetra. Aliquam euismod elit non ipsum <span>lacinia</span> consectetur.</p>
					<a href="#">ORDER NOW</a>	
				 </div>					 
			 </div>
			 <div class="clearfix"></div>
		  </div>
      </div>
</div>
-->




<div id="contact" class="contact">
	 <div class="container">
		 <div class="contact-text">

			<h3>Bizimle İletişime Geç</h3>			
		 </div>
		 <div class="contact-grids">
			 <div class="col-md-4 contact-grid text-center wow bounceIn" data-wow-delay="0.4s">
				 <div class="icon1"></div>
				 <p>Phone: +90 530 366 06 31</p>
			 </div>
			<div class="col-md-4 contact-grid text-center wow bounceIn" data-wow-delay="0.4s">
				 <div class="icon2"></div>
				<a rel="nofollow" href="https://discord.gg/Cmr939B"><p>Discord Adresimiz</p></a>
				<!-- <p>Suite 1900</p>
				 <p>Miami, FL 33131</p>-->
			 </div>
			 <div class="col-md-4 contact-grid text-center wow bounceIn" data-wow-delay="0.4s">
				 <div class="icon3"></div>
				 <a title="Bize eMail At!" href="mailto:info@voiddevelopment.com">info@voiddevelopment.com</a>
			 </div>
			 <div class="clearfix"></div>
		 </div>
		 
		 <div class="contact-details">
			 <form action="https://formspree.io/info@voiddevelopment.com" method="POST">
				 <div class="col-md-6 contact-left">
				     
				     
					 <input type="text" class="text wow fadeInLeft" data-wow-delay="0.4s" value="Ad Soyad *" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name *';}" name="isim" id="isim">
					 
					 
					 <input type="text" class="text wow fadeInLeft" data-wow-delay="0.4s" value="eMail *" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email *';}"  name="email" id="email">
					 
					 <input type="text" class="text wow fadeInLeft" data-wow-delay="0.4s" value="Konu *" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Subject *';}" name="konu" id="konu">
				 </div>
				 
				 <div class="col-md-6 contact-right">
					 <textarea class="wow fadeInRight"  name="mesaj" id="mesaj" data-wow-delay="0.4s" value="Mesajınız..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}">Mesajınız...</textarea>
					 
					 
					 <input class="wow fadeInRight" data-wow-delay="0.4s" type="submit" value="Mesajı Gönder"/>
				 </div>
				 <div class="clearfix"></div>
			 </form>
		 </div>	
		 
		 
		 
		 
		 
		 
		 
	 </div>
	 <div class="map">
		 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3593.1651928596452!2d-80.18708473414607!3d25.765106655121123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88d9b42909d18c97%3A0x97689362b4db9e7e!2sBrickell+Park!5e0!3m2!1sen!2sin!4v1425979652981" frameborder="0" style="border:0"></iframe>
	 </div>
</div>
<!---->
<div class="footer text-center">
	 <div class="container">
		 <div class="social">			 
			 <a href="#"><span class="behance"></span></a>
			 <a rel="nofollow" href="https://discord.gg/Cmr939B"><span class="dribble"><i class="fab fa-discord"></i></span></a>
			 <a href="#"><span class="twitter"></span></a>
			 <a href="#"><span class="facebook"></span></a>
			 <a href="#"><span class="linkedin"></span></a>
		 </div>
		 <p class="wow bounceIn" data-wow-delay="0.4s">Copyright &copy; 2020 Void Development Team™ All rights reserved |<a rel="nofollow" href="http://w3layouts.com">  W3layouts</a></p>
	 </div>
</div>
<!---->






<script type="text/javascript">
		$(document).ready(function() {
				/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
				*/
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!---->

 </body>
 </html>